setcolors.vim
=============

Shameless rip from http://vim.wikia.com/wiki/Switch_color_schemes#Script

Install via [Pathogen](https://github.com/tpope/vim-pathogen):

    cd ~/.vim/bundle
    git clone https://github.com/felixhummel/setcolors.vim.git setcolors

