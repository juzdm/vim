Noto Mono for Powerline
=======================

:Font creator: Google (company)
:Source: https://www.google.com/get/noto/
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Daniel Wood <https://github.com/theamazingfedex>`_

When text is rendered by a computer, sometimes characters are displayed as 
“tofu”. They are little boxes to indicate your device doesn’t have a font to 
display the text.

Google has been developing a font family called Noto, which aims to support all 
languages with a harmonious look and feel. Noto is Google’s answer to tofu. The 
name noto is to convey the idea that Google’s goal is to see “no more tofu”. 
Noto has multiple styles and weights, and is freely available to all.
