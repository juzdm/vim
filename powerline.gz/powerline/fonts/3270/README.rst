3270
====

:Font creator: Ricardo Bánffy
:Version: 1.2.14
:Source: https://github.com/rbanffy/3270font
:License: BSD/CCAS 3.0
:Patched by: N/A

The 3270 font is derived from the x3270 font, which, in turn, was
translated from the one in Georgia Tech's 3270tool, which was itself
hand-copied from a 3270-series terminal.

Both the final font Truetype/OpenType files and the design files used
to produce the font family are distributed under an open licence and
you are expressly encouraged to experiment, modify, share and improve.
